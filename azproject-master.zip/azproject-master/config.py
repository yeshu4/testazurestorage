[DEFAULT]
# Account name
account =storage3121
# Azure Storage account access key
key =tf2xNbMuBYORYtd+24fAc2coc8I9C4fJbXwmxgeFlOqyaU4zLhr7TLTC0D9cu6R3aXKhf6yX0TQBaMLh2AHvmw==
# Container name
container =upload
