# Set the VM up
Steps to set up the VMs for you!


For both the VMs, follow the steps to set them up :
  1. Type the command "git clone https://github.com/hshar94/azproject.git"
  2. "cd azproject"
  3. For VM1 : "./vm1.sh"
     For VM2 : "./vm2.sh"
    
